var express = require('express');
var route = express.Router();
var mongoose = require('mongoose');
var bcryptjs = require('bcryptjs');
var jwt = require('jsonwebtoken');

var User = require('../models/user');
var userController = require('../controller/user');

route.post('/signup', userController.user_signup);

route.post('/login', userController.user_login);

route.delete('/:userId', userController.user_delete);

module.exports = route;
