var express = require('express');
var route = express.Router();
var mongoose = require('mongoose');
var multer = require('multer');
var checkAuth = require('../middleware/checkAuth');

var storage = multer.diskStorage({
  destination: function(req, file, cb){
    cb(null, 'upload/');
  },
  filename: function(req, file, cb){
    cb(null, file.originalname);
  }
});
var fileFilter = function(req, file, cb){
  if(file.mimetype === 'image/png' || file.mimetype === 'image/jpeg' || file.mimetype === 'image/jpg'){
  cb(null, true);
} else {
  cb(new Error('file must be in png format'), false);
}
};
var upload = multer({storage: storage, limits: {
  fileSize: 1024 * 1024
},
fileFilter: fileFilter
});

var Product = require('../models/product');
var productController = require('../controller/product');

route.get('/', productController.product_gets_all);

route.post('/', checkAuth,upload.single('productImage'), productController.product_create_product);

route.get('/:productId', productController.product_get_one);

route.patch('/:productId', checkAuth, productController.product_update_one);

route.delete('/:productId', checkAuth, productController.product_delete_one);

module.exports = route;
