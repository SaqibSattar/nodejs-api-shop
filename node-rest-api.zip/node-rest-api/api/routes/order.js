var express = require('express');
var route = express.Router();
var mongoose = require('mongoose');

var Order = require('../models/order');
var Product = require('../models/product');
var checkAuth = require('../middleware/checkAuth');

var orderController = require('../controller/order');

route.get('/', checkAuth, orderController.order_gets_all);

route.post('/', checkAuth, orderController.order_create_order);

route.get('/:orderId', checkAuth, orderController.order_gets_one);

route.delete('/:orderId', checkAuth, orderController.order_delete_one);


module.exports = route;
