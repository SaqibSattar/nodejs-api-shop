var Product = require('../models/product');
var mongoose = require('mongoose');

exports.product_gets_all = (req, res, next) => {
  Product.find().select('name price _id productImage').exec().then(doc => {
    var response = {
      count: doc.length,
      Product: doc.map(doc => {
        return {
          name: doc.name,
          price: doc.price,
          _id: doc._id,
          productImage: doc.productImage,
          Request: {
            type: 'GET',
            url: 'http://localhost:3000/product/' + doc._id
          }
        }
      })
    };
    res.status(200).json(response);
  }).catch(err => {
    console.log(err);
    res.status(500).json({
      error: err
    })
  });
}


exports.product_create_product = (req, res, next) => {
  console.log(req.file);
  var product = new Product({
    _id: new mongoose.Types.ObjectId(),
    name: req.body.name,
    price: req.body.price,
    productImage: req.file.path
  });
  product.save().then(result => {
      res.status(200).json({
        ProductPro: {
          name: result.name,
          price: result.price,
          _id: result._id,
          productImage: req.file.path,
          Request: {
            type: 'POST',
            url: 'http://localhost:3000/product/' + result._id
          }
        }
      });
    })
    .catch(err => {
      console.log(err);
      res.status(500).json({
        Error: err
      });
    });

}


exports.product_get_one = (req, res, next) => {
  var id = req.params.productId;
  Product.findById(id).select('name price _id productImage').exec().then(doc => {
    console.log(doc);
    if (doc) {
      res.status(200).json({
        Product: doc,
        Request: {
          Message: 'Get all Products at this URL',
          url: 'http://localhost:3000/product/'
        }
      });
    } else {
      res.status(404).json({
        error: 'No Records found for that ID'
      })
    }
  }).catch(err => {
    console.log(err);
    res.status(500).json({
      error: err
    })
  });
}



exports.product_update_one = (req, res, next) => {
 var id = req.params.productId;
 var productOps = {};
 for (var ops of req.body) {
   productOps[ops.propName] = ops.value;
 }
 console.log(productOps);
 Product.update({
     _id: id
   }, {
     $set: productOps
   })
   .exec()
   .then(doc => {
     res.status(200).json({
       Message: 'Product successfully Updated',
       Request: {
         type: 'GET',
         url : 'http://localhost:3000/product/' + id
       }

     });
   }).catch(err => {
     console.log(err);
     res.status(500).json({
       error: err
     });
   });
}



exports.product_delete_one = (req, res, next) => {
 var id = req.params.productId;
 Product.remove({
     _id: id
   })
   .exec()
   .then(doc => {
     res.status(200).json({
       Message: 'Product successfully deleted',
       Request: {
         type: 'POST',
         visit: 'Get list of all Products',
         url : 'http://localhost:3000/product/'
       }
     });
   }).catch(err => {
     console.log(err);
     res.status(500).json({
       error: err
     });
   });
}
