var Order = require('../models/order');
var Product = require('../models/product');
var mongoose = require('mongoose');

exports.order_gets_all = (req, res, next) => {
  Order.find().select('product quantity _id').populate('product')
  .exec()
  .then(doc => {
    res.status(200).json({
      count: doc.length,
      orders : doc.map(doc => {
        return {
          _id: doc._id,
          quantity: doc.quantity,
          product: doc.product,
          Request: {
            type: 'GET',
            Url: 'http://localhost:3000/order/' + doc._id
          }
        }
      })
    });
  }).catch(err => {
    console.log(err);
    res.status(500).json({
      error: err
    })
  });
}

exports.order_create_order = (req, res, next) => {
  Product.findById(req.body.productId)
  .then(product =>{
    if(!product){
      return res.status(404).json({
        Error: 'Product not found.'
      })
    }
        var order = new Order({
          _id: new mongoose.Types.ObjectId(),
          product: req.body.productId,
          quantity: req.body.quantity
        });
        return order.save();
      })
      .then(result => {
        console.log(result);
        res.status(201).json({
          Message: 'Order successfully Stored',
          OrderStatus: {
            _id : result._id,
            quantity: result.quantity,
            product: result.product
          },
          Request: {
            type: 'POST',
            Url: 'http://localhost:3000/order/' + result._id
          }
        });
        })
        .catch(err => {
          res.status(500).json({
            error: err
        });
      });
  }

exports.order_gets_one = (req, res, next) => {
  var id = req.params.orderId;
  Order.findById(id).select('product quantity _id').populate('product')
  .exec()
  .then(doc => {
    console.log(doc);
    if (doc) {
      res.status(200).json({
        Order: doc,
        Request: {
          Message: 'Get all Orders at this URL',
          url: 'http://localhost:3000/order/'
        }
      });
    } else {
      res.status(404).json({
        error: 'No Records found for that ID'
      })
    }
  }).catch(err => {
    console.log(err);
    res.status(500).json({
      error: err
    })
  });
}


exports.order_delete_one = (req, res, next) => {
  var id = req.params.orderId;
  Order.remove({
      _id: id
    })
    .exec()
    .then(doc => {
      res.status(200).json({
        Message: 'Order successfully deleted',
        Request: {
          type: 'POST',
          visit: 'Get list of all Orders',
          url : 'http://localhost:3000/order/'
        }
      });
    }).catch(err => {
      console.log(err);
      res.status(500).json({
        error: err
      });
    });
}
